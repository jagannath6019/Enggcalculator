package com.example.enggcalculator

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {
    private lateinit var formulaInput: EditText
    private lateinit var variablesInput: EditText
    private lateinit var calcButton: Button
    private lateinit var resultView: TextView
    private lateinit var historyView: TextView
    private val historyList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        formulaInput = findViewById(R.id.formulaInput)
        variablesInput = findViewById(R.id.variablesInput)
        calcButton = findViewById(R.id.calcButton)
        resultView = findViewById(R.id.resultView)
        historyView = findViewById(R.id.historyView)

        calcButton.setOnClickListener { calculateFormula() }
    }

    private fun calculateFormula() {
        val formula = formulaInput.text.toString()
        val vars = variablesInput.text.toString()

        if (formula.isEmpty() || vars.isEmpty()) {
            Toast.makeText(this, "Enter formula and variables", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val expression = ExpressionBuilder(formula).build()
            val pairs = vars.split(",")
            for (pair in pairs) {
                val (key, value) = pair.split("=")
                expression.setVariable(key.trim(), value.trim().toDouble())
            }

            val result = expression.evaluate()
            resultView.text = "Result: $result"
            val entry = "$formula | $vars = $result"
            historyList.add(0, entry)
            if (historyList.size > 5) historyList.removeLast()
            historyView.text = "History:\n" + historyList.joinToString("\n")

        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
